<p align="center"><img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTm_viVue7cigCbzc_puEEqJzzzImgaIyviKg&usqp=CAU" width="128" height="128"/>
</p>
<p align="center">
<a href="#"><img title="Erza-Bot" src="https://img.shields.io/badge/Erza Bot-green?colorA=%23ff0000&colorB=%23017e40&style=for-the-badge"></a>
</p>
<!-- <img src="https://raw.githubusercontent.com/MRHRTZ/DGC-ChatBotV3/main/media/img/dgc.jpg" width="128" height="128"/> -->
<p align="center">
<a href="//github.com/inirey"><img src="https://img.shields.io/badge/Author-Rey-red.svg?style=for-the-badge&logo=github"/><a/>
</p>
<p align="center">
<a href="https://www.codefactor.io/repository/github/inirey/whatsapp-bot/overview/main"><img title="Rating" src="https://www.codefactor.io/repository/github/inirey/whatsapp-bot/badge/main"></a>
</p>
<p align="center">
<a href="https://javascript.com"><img src="https://img.shields.io/badge/Made%20With-javascript-cyan.svg?style=for-the-badge&logo=javascript"/><a/>
</p>
<p align="center">
<a href="https://github.com/inirey/whatsapp-bot/network/members"><img title="Forks" src="https://img.shields.io/github/forks/inirey/whatsapp-bot?color=red&style=flat-square"></a>
<a href="https://github.com/inirey/whatsapp-bot/watchers"><img title="Watching" src="https://img.shields.io/github/watchers/inirey/whatsapp-bot?label=Watchers&color=blue&style=flat-square"></a>
<a href="https://github.com/inirey/whatsapp-bot"><img title="Followers" src="https://img.shields.io/github/followers/inirey?color=blue&style=flat-square"></a>
<a href="https://github.com/inirey/whatsapp-bot/stargazers/"><img title="Stars" src="https://img.shields.io/github/stars/inirey/whatsapp-bot?color=red&style=flat-square"></a>
</p>

## WHATSAPP BOT GROUP
<a href="https://chat.whatsapp.com/D7L8NP2Vnz7Eplx4OAvZdP"><img title="WHATSAPP GROUP" src="https://img.shields.io/badge/Whatsapp Group-green?colorA=%23ff0000&colorB=%23017e40&style=for-the-badge"></a>

## DEPLOY HEROKUAPP
[![Deploy](https://www.herokucdn.com/deploy/button.svg)](https://heroku.com/deploy?template=https://github.com/inirey/whatsapp-bot/)
* Jika sudah mempunyai code session nya tinggal buat file session.data.json dan tempelkan kode nya di dalam file tersebut 
* If you already have the session code, just create a session.data.json file and paste the code in the file
* dan untuk termux silahkan beralih ke branch termux
* and for termux users, please switch to the termux branch if it still doesn't support please just run using herokuapp, thanks

## ADD BUILDPACK HEROKU
* heroku/nodejs
* https://github.com/jonathanong/heroku-buildpack-ffmpeg-latest.git
* https://github.com/DuckyTeam/heroku-buildpack-imagemagick.git

---------

## USERS WINDOWS/VPS/RDP

* Instal Git [`click here`](https://git-scm.com/downloads)
* Instal NodeJS [`click here`](https://nodejs.org/en/download)
* Instal FFmpeg [`click here`](https://ffmpeg.org/download.html)
* Instal ImageMagick [`click here`](https://imagemagick.org/script/download.php)

## USERS TERMUX

```bash
git clone https://github.com/inirey/whatsapp-bot --branch termux
cd whatsapp-bot
apt install clang libpixman librsvg giflib libpng libjpeg-turbo pango libcairo xorgproto
npm i
npm update
node .
```

---------

### Thanks To 
[`@Nurutomo`](https://github.com/Nurutomo)
[`@ariffb`](https://github.com/ariffb25)
