pkg install nodejs -y
pkg install ffmpeg -y
pkg install imagemagick -y
apt install clang libpixman librsvg giflib libpng libjpeg-turbo pango libcairo xorgproto
npm i
npm install
npm update
